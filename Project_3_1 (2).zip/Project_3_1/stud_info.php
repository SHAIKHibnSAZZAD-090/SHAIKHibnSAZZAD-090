<?php
$msg = ''; 

$host ='localhost:3306'; 
$userName = 'root'; 
$userPass = ''; 
$database = "3_1project"; 

$connectQuery = mysqli_connect($host, $userName, $userPass, $database);

if (mysqli_connect_errno()) {
    echo mysqli_connect_error();
    exit();
} else {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Check if a delete button was clicked
        if (isset($_POST["delete"])) {
            $row_id = $_POST["delete"];
            // Perform the delete query
            $deleteQuery = "DELETE FROM `student` WHERE `roll` = $row_id";
            if (mysqli_query($connectQuery, $deleteQuery)) {
                $msg = "Record with Roll Number $row_id has been deleted successfully.";
            } else {
                $msg = "Error deleting record: " . mysqli_error($connectQuery);
            }
        }
    }

    $selectQuery = "SELECT * FROM `student` ORDER BY `roll` ASC";
    $result = mysqli_query($connectQuery, $selectQuery);
    if (mysqli_num_rows($result) > 0) {
        
    } else {
        $msg = "No Record found";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>student_info</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
        }

        h1 {
            text-align: center;
            color: #007BFF;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 10px;
            border-bottom: 1px solid #ccc;
            text-align: left;
        }

        th {
            background-color: #007BFF;
            color: #fff;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #ddd;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Information about the Registered Students</h1>
        <?=$msg;?>
        <table border="1" style="width:100%; line-height:40px;">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Roll</th>
                    <th>Registration No</th>
                    <th>Action</th> 
                </tr>
            </thead>
            <tbody>
                <?php
                while ($row = mysqli_fetch_assoc($result)) {
                ?>
                    <tr>
                        <td><?php echo $row['name']; ?></td>
                        <td><?php echo $row['email']; ?></td>
                        <td><?php echo $row['roll']; ?></td>
                        <td><?php echo $row['registration_no']; ?></td>
                        <td>
                            <form method="post">
                                <button type="submit" name="delete" value="<?php echo $row['roll']; ?>">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php
                }
                ?>
            </tbody>
        </table>
    </div>
    <a href="admin_page.php" class="btn" style="display: flex; justify-content: center; align-items:center; background-color: #007BFF; color: #fff; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Back to admin page</a>

</body>
</html>
