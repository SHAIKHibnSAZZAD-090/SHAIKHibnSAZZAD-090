<?php

@include 'config.php';

session_start();

if(!isset($_SESSION['user_name'])){
   header('location:login_form.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>user page</title>

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<div class="container">

   <div class="content">
   <img src="ruet_moto.jpg" alt="RUET" width="250" height="250" style="
    display: block;
    margin: 0 auto;
    border: 4px solid #ccc;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
">

   <h2 style="text-align: center;">Rajshahi University of Engineering and Technology</h2>
      <h3>Hi, <span>user</span></h3>
      <h2>welcome <span><?php echo $_SESSION['user_name'] ?></span></h2>
      <a href="stud_profile.php" class="btn"><b>My profile</b></a>
      <b><a href="process_form.php" class="btn">exam_registration</a></b>
      <b><a href="course_regis.php" class="btn">Course_registration</a></b>
      <b><a href="welcome.php" class="btn">logout</a></b>
   </div>

</div>

</body>
</html>