<!DOCTYPE html>
<html>
<head>
    <title>Course Registration Data</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #FFF8DC;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
        }

        h1 {
            text-align: center;
            color: #007BFF;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 10px;
            border-bottom: 1px solid #ccc;
            text-align: left;
        }

        th {
            background-color: #007BFF;
            color: #fff;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #D6EAF8;
        }
    </style>
</head>
<body>
    <div class="container">
    <h2 style="text-align: center;"> Registered student and their Information</h2>

        <?php
        $servername = "localhost:3306";
        $username = "root";
        $password = "";
        $dbname = "3_1project";

        // Create a connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $sql = "SELECT * FROM course_registered";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            echo '<table border="1" style="width:100%; line-height:40px;">';
            echo '<thead>';
            echo '<tr>';
            echo '<th>Name</th>';
            echo '<th>Roll Number</th>';
            echo '<th>Session</th>';
            echo '<th>Earned Credit</th>';
            echo '<th>Selected Semester</th>';
            echo '<th> Selected Courses</th>';
            echo '</tr>';
            echo '</thead>';
            echo '<tbody>';

            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["name"] . "</td>";
                echo "<td>" . $row["rollNumber"] . "</td>";
                echo "<td>" . $row["session"] . "</td>";
                echo "<td>" . $row["earnedCredit"] . "</td>";
                echo "<td>" . $row["selectedSemester"] . "</td>";
                echo "<td>" . $row["courses"] . "</td>";
                echo "</tr>";
            }

            echo '</tbody>';
            echo '</table>';
        } else {
            echo "<p>No records found</p>";
        }

        // Close the database connection
        $conn->close();
        ?>
         <a href="admin_page.php" class="btn" style="display: flex; justify-content: center; align-items:center; background-color: #800080; color: #fff; padding: 10px 20px; border-radius: 5px;">Back to admin page</a>
    </div>
</body>
</html>
