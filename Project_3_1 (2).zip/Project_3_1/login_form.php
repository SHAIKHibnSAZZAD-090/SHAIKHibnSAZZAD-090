<?php

@include 'config.php';

session_start();


if(isset($_POST['submit'])){


   $email = mysqli_real_escape_string($conn, $_POST['email']);
   $pass = $_POST['password'];
   $user_type = $_POST['user_type'];


   if($user_type == 'student'){
      $select = " SELECT * FROM student WHERE email = '$email' && password = '$pass' ";
   }
   else{
      $select = " SELECT * FROM teacher WHERE email = '$email' && password = '$pass' ";
   }
  

   $result = mysqli_query($conn, $select);

   if(mysqli_num_rows($result) > 0){
      
      $row = mysqli_fetch_array($result);

      if($user_type == 'teacher'){

         $_SESSION['admin_name'] = $row['name'];
         
         header('location:admin_page.php');

      }elseif($user_type == 'student'){

         $_SESSION['user_name'] = $row['name'];
         
         $sql = " SELECT roll FROM student WHERE email = '$email' && password = '$pass' ";
$result = $conn->query($sql);

// Check if a row is returned
if ($result->num_rows == 1) {
    // Fetch the roll value from the result
    $row = $result->fetch_assoc();
    $roll = $row["roll"];
    
    // Store the roll value in the session
    $_SESSION['roll'] = $roll;
    
    
}
         header('location:user_page.php');

      }
     
   }else{
      $error[] = 'incorrect email or password!';
   }

};
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>login form</title>

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<div class="form-container">

   <form action="" method="post" id="login_form">
      <h3>login now</h3>
      <?php
      if(isset($error)){
         foreach($error as $error){
            echo '<span class="error-msg">'.$error.'</span>';
         };
      };
      ?>
      <input type="email" name="email" required placeholder="enter your email">
      <input type="password" name="password" required placeholder="enter your password">
    
      <select name="user_type" onchange="shift(event)">
         <option value="student" selected>student</option>
         <option value="teacher">teacher</option>
      </select>
      <input type="submit" name="submit" value="login now" class="form-btn">
      <p>don't have an account? <a href="register_form.php">register now</a></p>
   </form>

</div>

</body>
</html>