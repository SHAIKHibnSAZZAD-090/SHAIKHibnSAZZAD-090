<?php
session_start();

$roll = $_SESSION['roll'];

$name= $_SESSION['user_name'];

?>
<!DOCTYPE html>
<html>
<head>
  <title>Semester Registration Form</title>
  <style>
     body {
      font-family: 'Times New Roman', Times, serif;
      background-color: lightblue; 
    }

    h1 {
      text-align: center;
    }

    .container {
      max-width: 800px;
      margin: 0 auto;
      padding: 20px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }

    .form-group {
      margin-bottom: 20px;
    }

    .form-group label {
      display: block;
      font-weight: bold;
      margin-bottom: 5px;
    }

    .form-group input[type="text"],
    .form-group input[type="number"] {
      width: 100%;
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }

    .semester-group {
      margin-bottom: 20px;
    }

    .semester-group label {
      font-weight: bold;
      margin-bottom: 5px;
    }

    .course-list {
      padding-left: 20px;
    }

    .course-list label {
      display: block;
      margin-bottom: 5px;
    }

    .submit-btn {
      display: block;
      width: 100%;
      padding: 10px;
      background-color: #4CAF50;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }
  </style>
</head>
<body>
  <h1>Semester Registration Form</h1>
  <div class="container">
    <form action="course_regis.php" method="post"> 
      <div class="form-group">
        <label for="name">Student Name:</label>
        <input type="text" id="name" name="name" required placeholder="Enter your name">
      </div>
      <div class="form-group">
        <label for="Roll-No">Roll Number:</label>
        <?php
        echo '<input type="text" disabled value='.$roll.'>';
        echo '<input type="text" id="roll" name="roll" hidden value='.$roll.'>';
        ?>
      </div>
      <div class="form-group">
        <label for="session">Session:</label>
        <input type="text" id="session" name="session" required placeholder="Enter your session">
      </div>
      <div class="form-group">
        <label for="Credit">Previously earned credit:</label>
        <input type="text" id="Credit" name="earnedCredit" required placeholder="Enter your previously earned credit">
      </div>
      <div class="semester-group">
        <label for="semester">Select Semester:</label>
        <select id="semester" name="selectedSemester">
          <option value="1">1st Semester</option>
          <option value="2">2nd Semester</option>
          <option value="3">3rd Semester</option>
          <option value="4">4th Semester</option>
          <option value="5">5th Semester</option>
          <option value="6">6th Semester</option>
          <option value="7">7th Semester</option>
          <option value="8">8th Semester</option>
        </select>
      </div>
      <div id="course-list-container" class="form-group">
        <label>Course List:</label>
        <div id="course-list" class="course-list"></div>
      </div>
      <button type="submit" class="submit-btn">Submit</button>
    </form>
    <b><a href="user_page.php" class="btn">Back to User Page</a></b>
  </div>

  <script>
    var courseData = {
      1: ["CSE 1100:Computer Fundamentals and Ethics",
       "CSE 1101:Computer Programming", 
       "CSE 1102:Sessional Based on CSE 1101",
        "EEE 1151:Basic Electrical Engineering",
         "EEE 1152:Sessional Based on EEE 1151",
         "Math 1113:Differential and Integral Calculus", 
         "Hum 1113:Functional English",
         "Hum 1114:English Language Lab", 
         "Chem 1113:Inorganic and Physical Chemistry",
         "Chem 1114:Sessional Based on Chem 1113"],
         2: ["CSE 1200: Analytical Programming",
       "CSE 1201: Data Structure", 
       "CSE 1202: Sessional Based on CSE 1201", 
       "CSE 1203: Object Oriented Programming", 
       "CSE 1204: Sessional Based on CSE 1203", 
       "Math 1213: Co-ordinate Geometry and Ordinary Differential Equation", 
       "Hum 1213: Economics,Government & Sociology", 
       "Phy 1213: Physics", 
       "Phy 1214: Sessional Based on Phy 1213"],

      3: ["CSE 2100: Software Development Project I",
       "CSE 2101: Discrete Mathematics", 
       "CSE 2102: Sessional Based on CSE 2101",
        "CSE 2103: Numerical Methods",
         "CSE 2104: Sessional Based on CSE 2103", 
         "EEE 2151: Analog Electronics",
          "EEE 2152: Sessional Based on EEE 2151",
           "Math 2113: Vector Analysis and Linear Algebra",
            "Hum 2113: Industrial Management & Accountancy"],

      4: ["CSE 2201:Computer Algorithms",
       "CSE 2202: Sessional Based on CSE 2201",
        "CSE 2203: Digital Techniques",
         "CSE 2204: Sessional Based on CSE 2203",
          "CSE 2205: Finite Automata Theory",
           "CSE 2206: Sessional Based on CSE 2205",
            "EEE 2251: Electrical Machines & Instrumentations",
             "EEE 2252: Sessional Based on EEE 2251",
            "Math 2213: Complex Variable, Differential Equations and Harmonic Analysis"
          ],

      5: ["CSE 3100: Web Based Application Lab/Project",
         "CSE 3101: Database Systems",
         "CSE 3102: Sessional Based on CSE 3101",
         "CSE 3103: Data Communication", 
         "CSE 3104: Sessional Based on CSE 3103", 
         "CSE 3105: Software Engineering ", 
         "CSE 3107: Applied Statistics & Queuing Theory", 
         "CSE 3109: Microprocessors & Assembly Language", 
         "CSE 3110: Sessional Based on CSE 3109", 
         "CSE 3112: Technical Writing and Presentation"],

      6: ["CSE 3200: Software Development Project II",
       "CSE 3201: Operating Systems",
        "CSE 3202: Sessional Based on CSE 3201", 
        "CSE 3203: Computer Architecture and Design", 
        "CSE 3205: Computer Networks", 
        "CSE 3206: Sessional Based on CSE 3205", 
        "CSE 3207: Peripherals & Interfacings", 
        "CSE 3208: Sessional Based on CSE 3207", 
        "CSE 3209: Artificial Intelligence", 
        "CSE 3210: Sessional Based on CSE 3209"],

      7: ["CSE 4000: Project/Thesis I", 
      "CSE 4101: Compiler Design", 
      "CSE 4102: Sessional Based on CSE 4101", 
      "CSE 4103: Digital Signal Processing", 
      "CSE 4104: Sessional Based on CSE 4103", 
      "CSE 4105: Digital Image Processing", 
      "CSE 4106: Sessional Based on CSE 4105", 
      "CSE ****: Optional I", 
      "CSE ****: Sessional Based on Optional I", 
      "CSE ****: Optional II"],

      8: ["CSE 4000: Project/Thesis II", 
      "CSE 4201: Computer Graphics and Animations", 
      "CSE 4202: Sessional Based on CSE 4201", 
      "CSE 4203: Neural Networks & Fuzzy Systems", 
      "CSE 4204: Sessional Based on CSE 4203", 
      "CSE 4206: Seminar", 
      "CSE ****: Optional I", 
      "CSE ****: Optional II ", 
      "CSE ****: Optional III ", ]
    };

    var semesterSelect = document.getElementById("semester");
    var courseListContainer = document.getElementById("course-list");

    function updateCourseList() {
      var semester = semesterSelect.value;
      var courses = courseData[semester];
      var courseListHTML = "";

      for (var i = 0; i < courses.length; i++) {
        var courseId = "course-" + (i + 1);
        courseListHTML += '<label><input type="checkbox" name="courses[]" value="' + courses[i] + '"> ' + courses[i] + '</label>';
      }

      courseListContainer.innerHTML = courseListHTML;
    }

    semesterSelect.addEventListener("change", updateCourseList);
    updateCourseList();
  </script>
</body>
</html>
<?php
$servername = "localhost:3306";
$username = "root";
$password = ""; 
$dbname = "3_1project"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$stmt = $conn->prepare("INSERT INTO course_registered (name, rollNumber, session, earnedCredit, selectedSemester, courses) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssis", $name, $rollNumber, $session, $earnedCredit, $selectedSemester, $courses);

$name = "";
$rollNumber = "";
$session = "";
$earnedCredit = "";
$selectedSemester = 0; // Initialize to 0 or any default value
$courses = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["name"])) {
        $name = $_POST["name"];
    }
    if (isset( $_SESSION["roll"])) {
        $rollNumber = $_SESSION["roll"];
    }
    if (isset($_POST["session"])) {
        $session = $_POST["session"];
    }
    if (isset($_POST["earnedCredit"])) {
        $earnedCredit = $_POST["earnedCredit"];
    }
    if (isset($_POST["selectedSemester"])) {
        $selectedSemester = intval($_POST["selectedSemester"]);
    }
    if (isset($_POST["courses"]) && is_array($_POST["courses"])) {
        $courses = implode(", ", $_POST["courses"]);
    }

    try {
     
        if ($stmt->execute()) {
            echo '<div style="text-align:center; padding: 20px; background-color: #4CAF50; color: white; border-radius: 5px;">';
            echo 'Your course registration has been successfully completed and stored in the database record.';
            echo '</div>';
        } else {
            echo "Error: " . $stmt->error;
        }
    } catch (mysqli_sql_exception $e) {
        if ($e->getCode() == 1062) { // Error code for duplicate entry
            echo '<div style="text-align:center; padding: 20px; background-color: #FF5733; color: white; border-radius: 5px;">';
            echo 'Error: Duplicate entry. You have already registered for this semester.';
            echo '</div>';
        } else {
            echo "Error: " . $e->getMessage();
        }
    }
}


$stmt->close();
$conn->close();
?>
