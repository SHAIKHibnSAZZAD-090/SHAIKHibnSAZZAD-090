<?php

@include 'config.php';

session_start();

if(!isset($_SESSION['admin_name'])){
   header('location:login_form.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>admin page</title>
   
   <link rel="stylesheet" href="css/style.css">

</head>
<body>



<div class="container">
   <div class="content">
   <img src="ruet_moto.jpg" alt="RUET" width="250" height="250" style="display: block; margin: 0 auto;">
   <h2 style="text-align: center;">Rajshahi University of Engineering and Technology</h2>
      <h3>Hi, <span>admin</span></h3>
      <h2>welcome <span><?php echo $_SESSION['admin_name'] ?></span></h2>
      <a href="stud_info.php" class="btn"><b>Students Basic Info</b></a>
      <br><br>
      <a href="show.php" class="btn"><b>Exam Registered Students</b></a> 
      <br><br>
      <a href="course_regstd.php" class="btn"><b>Course Registered Students</b></a>  
      <br><br>
      <a href="profile.php" class="btn"><b>My profile</b></a>
      <br><br>
     <a href="welcome.php" class="btn"><b>Logout</b></a>     
   </div>

</div>

</body>
</html>