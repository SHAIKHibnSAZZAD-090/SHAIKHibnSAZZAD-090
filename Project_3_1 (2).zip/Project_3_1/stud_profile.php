<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <style>
        body {
            font-family: 'Times New Roman', Times, serif;
            background-color:#1B8A6B;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 110vh;
            background-image: url("bg_n.jpg");
            background-attachment: fixed;

        }

        .profile-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
        }

        h1 {
            text-align: center;
            text-emphasis-color: #008000;
        }

        .profile-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .profile-table th,
        .profile-table td {
            padding: 10px;
            border: 1px solid #0000A0;
            text-align: left;
        }

        .profile-table th {
            background-color: #50EBEC;
        }
    </style>
</head>
<body>
           
    <div class="profile-container">
    <img src="student_photo.jpg" alt="admin">

    <h1>User Profile</h1>
        <?php
        session_start();

        // Establish a database connection (replace with your actual database credentials)
        $link = mysqli_connect("localhost:3306", "root", '', "3_1project");

        if (!$link) {
            die("Connection failed: " . mysqli_connect_error());
        }

        $session_user = $_SESSION['user_name'];
        $session_user = mysqli_real_escape_string($link, $session_user);

        $user_data = mysqli_query($link, "SELECT * FROM `student` WHERE `name`='$session_user'");

        if ($user_data) {
            $admin_row = mysqli_fetch_assoc($user_data);
            
            echo '<table class="profile-table">';
            echo '<tr><th>Attribute</th><th>Value</th></tr>';
            echo '<tr><td>Name</td><td>' . $admin_row['name'] . '</td></tr>';
            echo '<tr><td>Email</td><td>' . $admin_row['email'] . '</td></tr>';
            echo '<tr><td>Roll</td><td>' . $admin_row['roll'] . '</td></tr>';
            echo '<tr><td>Registration No</td><td>' . $admin_row['registration_no'] . '</td></tr>';
            echo '<tr><td>Status</td><td>  Registered  </td></tr>';
            echo '</table>';
        } else {
            echo "Query failed: " . mysqli_error($link);
        }

        // Close the database connection when done
        mysqli_close($link);
        ?>
        <b><p style="color: #ccc;"><a href="user_page.php" class="button">Back to User page</a></p></b>
    </div>
    
</body>
</html>
