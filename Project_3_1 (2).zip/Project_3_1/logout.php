<?php

@include 'config.php';

session_start();
session_unset();//unset all the session variable
session_destroy();

header('location:welcome.php');

?>