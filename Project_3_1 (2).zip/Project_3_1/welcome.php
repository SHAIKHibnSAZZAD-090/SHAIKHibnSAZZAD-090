<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('RUET.jpg'); 
            background-size: cover; 
            background-repeat: no-repeat; /* Prevents image from repeating */
            background-attachment: fixed; /* Fixes the background image in place */
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            text-align: center;
        }
        
        .button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #007BFF;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            margin: 10px;
            transition: background-color 0.3s;
        }

        .button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
   <marquee behavior="scroll" direction="right"> <h1 style="color:#BFFF00; font-weight: bold;">Rajshahi University of Engineering & Technology</h1></marquee>

    <h2><b><p style="color:#00FFFF;font-family:roman">Heaven's Light is Our Guide</p></b></h2>
    <h2><b><p style="color:white">Welcome to course and Exam registraion System of RUET</p></b></h2>
    
        <h2><b><a href="register_form.php" class="button">Register</a></b></h2>
        <b><a href="login_form.php" class="button">Login</a></b>
    </div>
</body>
</html>
